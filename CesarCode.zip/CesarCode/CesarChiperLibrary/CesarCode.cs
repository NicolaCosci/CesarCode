﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CesarChiperLibrary
{
    public class CesarCode : CesarBase
    {
        public string ChiperText { get; set; }
        public CesarCode(string message, int Key)
        {
            Key = Key;
            ChiperText = DoWork(message);    
        }
        
    }

    
}
